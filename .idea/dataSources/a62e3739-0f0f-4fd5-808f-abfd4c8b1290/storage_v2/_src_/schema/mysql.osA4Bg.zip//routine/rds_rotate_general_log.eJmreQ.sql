create
    definer = rdsadmin@localhost procedure rds_rotate_general_log() deterministic
BEGIN
    DECLARE v_called_by_user VARCHAR(50);
    DECLARE v_mysql_version VARCHAR(20);
    DECLARE b_sql_log BOOLEAN;
    DECLARE b_general_query_log BOOLEAN;

    SELECT user() into v_called_by_user;
    SELECT version() into v_mysql_version;

    SELECT @@sql_log_bin INTO b_sql_log;
    SET @@sql_log_bin=OFF;

    DROP TABLE IF EXISTS mysql.general_log2;

    CREATE TABLE IF NOT EXISTS mysql.general_log2 LIKE mysql.general_log;
    DROP TABLE IF EXISTS mysql.general_log_backup;

    SELECT @@general_log INTO b_general_query_log;
    SET GLOBAL general_log=OFF;
    FLUSH GENERAL LOGS;
    RENAME TABLE mysql.general_log TO mysql.general_log_backup, mysql.general_log2 TO mysql.general_log;

    SET GLOBAL general_log=b_general_query_log;
    INSERT into mysql.rds_history(called_by_user, action, mysql_version) values (v_called_by_user, 'rotate_general_log', v_mysql_version);
    COMMIT;

    SET @@sql_log_bin = b_sql_log;

END;

