create definer = rdsadmin@localhost trigger block_user_u
    before update
    on user
    for each row
BEGIN
  DECLARE foo varchar(255);
  if old.User = "rdsadmin" then
    select `ERROR (RDS): CANNOT UPDATE RDSADMIN USER` into foo from mysql.user;
  end if;
 
  if old.User = "rdsrepladmin" then
    select `ERROR (RDS): CANNOT UPDATE RDSREPLADMIN USER` into foo from mysql.user;
  end if;
 
  if old.super_priv <> 'Y' and new.super_priv = 'Y' then
     select `ERROR (RDS): SUPER PRIVILEGE CANNOT BE GRANTED OR MAINTAINED` into foo from mysql.user;
   elseif old.shutdown_priv <> 'Y' and new.shutdown_priv = 'Y' then
     select `ERROR (RDS): SHUTDOWN PRIVILEGE CANNOT BE GRANTED OR MAINTAINED. PLEASE USE RDS API` into foo from mysql.user;
   elseif old.file_priv <> 'Y' and new.file_priv = 'Y' then
     select `ERROR (RDS): FILE PRIVILEGE CANNOT BE GRANTED OR MAINTAINED` into foo from mysql.user;
   elseif old.repl_slave_priv <> 'Y' and new.repl_slave_priv = 'Y' then
     select `ERROR (RDS): REPLICA SLAVE PRIVILEGE CANNOT BE GRANTED OR MAINTAINED` into foo from mysql.user;
   elseif old.repl_client_priv <> 'Y' and new.repl_client_priv = 'Y' then
       select `ERROR (RDS): REPLICA CLIENT PRIVILEGE CANNOT BE GRANTED OR MAINTAINED` into foo from mysql.user;
  end if; 
END;

