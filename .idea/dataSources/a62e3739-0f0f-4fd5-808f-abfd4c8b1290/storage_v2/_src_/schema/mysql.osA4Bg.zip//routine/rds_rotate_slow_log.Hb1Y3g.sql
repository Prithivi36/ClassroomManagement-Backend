create
    definer = rdsadmin@localhost procedure rds_rotate_slow_log() deterministic
BEGIN
    DECLARE v_called_by_user VARCHAR(50);
    DECLARE v_mysql_version VARCHAR(20);
    DECLARE b_sql_log BOOLEAN;
    DECLARE b_slow_query_log BOOLEAN;

    SELECT user() into v_called_by_user;
    SELECT version() into v_mysql_version;

    SELECT @@sql_log_bin INTO b_sql_log;
    SET @@sql_log_bin=OFF;

    DROP TABLE IF EXISTS mysql.slow_log2;

    CREATE TABLE IF NOT EXISTS mysql.slow_log2 LIKE mysql.slow_log;
    DROP TABLE IF EXISTS mysql.slow_log_backup;

    SELECT @@slow_query_log INTO b_slow_query_log;
    SET GLOBAL slow_query_log=OFF;
    FLUSH SLOW LOGS;
    RENAME TABLE mysql.slow_log TO mysql.slow_log_backup, mysql.slow_log2 TO mysql.slow_log;
    SET GLOBAL slow_query_log=b_slow_query_log;
    INSERT into mysql.rds_history(called_by_user, action, mysql_version) values (v_called_by_user, 'rotate_slow_log', v_mysql_version);
    COMMIT;

    SET @@sql_log_bin = b_sql_log;

END;

