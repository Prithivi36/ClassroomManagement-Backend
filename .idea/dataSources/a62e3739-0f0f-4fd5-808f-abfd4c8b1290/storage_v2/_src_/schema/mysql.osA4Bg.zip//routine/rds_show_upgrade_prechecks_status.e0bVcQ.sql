create
    definer = rdsadmin@localhost procedure rds_show_upgrade_prechecks_status()
BEGIN
    DECLARE v_called_by_user VARCHAR(50);
    DECLARE v_engine_version VARCHAR(50);
    DECLARE sql_logging BOOLEAN;
    SELECT @@sql_log_bin INTO sql_logging;

    BEGIN
        DECLARE EXIT HANDLER FOR SQLEXCEPTION
                BEGIN
                    SET @@sql_log_bin=sql_logging;
                    RESIGNAL;
                END;
        SET @@sql_log_bin=OFF;

        SELECT user() INTO v_called_by_user;
        SELECT version() INTO v_engine_version;

        
        INSERT INTO mysql.rds_history(called_by_user,action,mysql_version) VALUES (v_called_by_user,'show prechecks',v_engine_version);
        COMMIT;

        SELECT action, status, engine_version, target_engine_name, target_engine_version, start_timestamp, last_timestamp, prechecks_completed, prechecks_remaining FROM mysql.rds_upgrade_prechecks WHERE action IN ('precheck', 'engine upgrade') ORDER BY start_timestamp DESC LIMIT 1;
        
        INSERT INTO mysql.rds_history(called_by_user, action, mysql_version) VALUES (v_called_by_user, 'show prechecks:ok', v_engine_version);
        COMMIT;

        SET @@sql_log_bin=sql_logging;

    END;

END;

