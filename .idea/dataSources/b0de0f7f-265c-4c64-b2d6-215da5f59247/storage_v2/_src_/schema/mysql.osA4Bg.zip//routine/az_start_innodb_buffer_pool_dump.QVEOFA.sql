create
    definer = azure_superuser@localhost procedure az_start_innodb_buffer_pool_dump()
BEGIN    SET GLOBAL innodb_buffer_pool_dump_now = ON; END;

