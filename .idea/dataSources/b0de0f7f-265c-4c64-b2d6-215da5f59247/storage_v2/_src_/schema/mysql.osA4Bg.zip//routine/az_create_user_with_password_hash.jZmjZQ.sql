create
    definer = azure_superuser@localhost procedure az_create_user_with_password_hash(IN user char(32), IN host char(255), IN hash text)
    reads sql data
BEGIN    INSERT INTO mysql.user (User, Host, plugin, authentication_string, ssl_cipher, x509_issuer, x509_subject, password_last_changed) VALUES (user, host, 'mysql_native_password', hash, '', '', '', now());    FLUSH PRIVILEGES; END;

grant select on user to 'mysql.session'@localhost;

