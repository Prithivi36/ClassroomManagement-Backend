create
    definer = azure_superuser@localhost procedure az_add_action_history(IN ACTION_ID varchar(36),
                                                                        IN ACTION_OWNER varchar(256),
                                                                        IN ACTION_NAME varchar(256),
                                                                        IN ACTION_OPTION text,
                                                                        IN ACTION_STATE varchar(256))
    comment 'Azure MySQL stored procedure to add action hisotry.'
    sql security invoker
    modifies sql data
BEGIN DECLARE error_no INT DEFAULT 0; DECLARE error_message TEXT; DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN     GET DIAGNOSTICS @cno = NUMBER;     GET DIAGNOSTICS CONDITION @cno error_no = MYSQL_ERRNO, error_message = MESSAGE_TEXT;     SELECT 'Exception while adding the action history.' AS exception,  error_no AS mysql_error_code, error_message AS message; END; SET @h_action_id = ACTION_ID; SET @h_current_user = ACTION_OWNER; SET @h_mysql_version = VERSION(); SET @h_action_name = ACTION_NAME; SET @h_action_option = ACTION_OPTION; SET @h_action_state = ACTION_STATE; SET @h_now_utc = UTC_TIMESTAMP(); /* Update action hisory. */ SET @insert_action_history_exp = 'INSERT INTO `mysql`.`__az_action_history__` (`ACTION_UUID`, `USER`, `VERSION`, `ACTION`, `OPTION`, `STATUS`, `UPDATED_TIME`) VALUES (?, ?, ?, ?, ?, ?, ?);'; PREPARE insert_action_history_query FROM @insert_action_history_exp; EXECUTE insert_action_history_query USING @h_action_id, @h_current_user, @h_mysql_version, @h_action_name, @h_action_option, @h_action_state, @h_now_utc; DEALLOCATE PREPARE insert_action_history_query; COMMIT; SET @h_action_id = NULL; SET @h_current_user = NULL; SET @h_mysql_version = NULL; SET @h_action_name = NULL; SET @h_action_option = NULL; SET @h_action_state = NULL; SET @h_now_utc = NULL; SET @insert_action_history_exp = NULL; END;

